<%*

/*

Updated: 8/16/2021

Author: TfTHacker + Maggie Delano 

Gist: https://gist.github.com/maggiedelano

Twitter: https://twitter.com/TfTHacker, https://twitter.com/maggiedelano

Requirements: Templater Plugin for Obsidian

Description: This script performs the following actions:

1. Moves current file to the system trash

2. Opens next file in current folder into the active window pane in Obsidian

Installation:

- In the templates folder, create a file called TrashAndProcessNextFile.md

- the file must have an .md extension, not a .js extension

- Copy the contents of this gist to the file you created

- Invoke the templater plugin from the Obisidian Command Palette and then select the TrashAndProcessNextFile.md file

*/


let currentFolderPath = tp.file.folder(true);

let currentFilePath = (currentFolderPath=='/' ? '' : currentFolderPath + '/') + tp.file.title + '.md';

let sortFileList = (await app.vault.adapter.list( currentFolderPath )).files.sort( (a, b)=> a.localeCompare(b) );

const fileToDelete = await app.vault.getAbstractFileByPath(currentFilePath);

await app.vault.trash( fileToDelete ,true ); // trash current file

let currentFileIndexInCurrentFolder = sortFileList.findIndex( e=>e==currentFilePath );

if ( sortFileList.length>1) { // open next file in folder, if one exists

let nextFileToOpen = '';

if( currentFileIndexInCurrentFolder == sortFileList.length-1 )

nextFileToOpen = sortFileList[0];

else

nextFileToOpen = sortFileList[currentFileIndexInCurrentFolder+1];

app.workspace.activeLeaf.openFile( tp.file.find_tfile(nextFileToOpen) );

}

%>
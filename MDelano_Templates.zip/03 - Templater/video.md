---
title: null
author: null
year: null
tags: [ sources/video ]
url: null
---

# `=this.title`

## Permanent Notes
```dataview 
TABLE file.mday AS "Date"
FROM #permanentNote AND [[<% tp.file.title %>]]
sort file.mday DESC
```

## Literature Notes
```dataview 
TABLE file.mday AS "Date"
FROM #literatureNote AND [[<% tp.file.title %>]]
sort file.mday DESC
```

## Summary of Key Points
- 

## Fleeting Notes
- 

## Highlights

<% await tp.file.move("20 - Zettelkasten/23 - Sources/Videos/" + tp.file.title) %>
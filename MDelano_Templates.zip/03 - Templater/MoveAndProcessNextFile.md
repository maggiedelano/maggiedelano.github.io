<%*

/*

Updated: 8/6/2021

Author: TfTHacker

Gist: https://gist.github.com/TfTHacker

Twitter: https://twitter.com/TfTHacker

Requirements: Templater Plugin for Obsidian

Description: This script performs the following actions:

1. Moves current file to the archive folder (defined in the variable archivePath)

if archivePath is null, a folders in the vault will be presented for selection

examples:

let archivePath = null;

or:

let archivePath = '/test/path/;

2. Opens next file in current folder into the active window pane in Obsidian

*/

let archivePath = null;

// FUNCTION - saves the last destination folder to localStorage for list of Recent Folders

const setRecentFolderToLocalStorage = ( folderPath )=> {

const localStorage = window.localStorage.getItem('TfTHacker-RecentFolders');

let recentFilePathsInStorage = localStorage==null ? [] : localStorage.split(',');

if( !recentFilePathsInStorage.includes(folderPath) )

recentFilePathsInStorage.unshift(folderPath);

else {

recentFilePathsInStorage = recentFilePathsInStorage.filter( e=> e != folderPath ); //remove folder if already in list

recentFilePathsInStorage.unshift(folderPath); //add folder to top of the list

}

if(recentFilePathsInStorage.length>4) recentFilePathsInStorage = recentFilePathsInStorage.slice(0,5);

window.localStorage.setItem('TfTHacker-RecentFolders', recentFilePathsInStorage);

}

// FUNCTION - get the list of recent folders from localStorage

// folderList = array of existing folders.

const getRecentFoldersFromLocalStorage = (folderList)=>{

const localStorage = window.localStorage.getItem('TfTHacker-RecentFolders');

return localStorage!=null ? localStorage.split(',') : [];

}

// FUNCTION - create array of all folders at a given level

// searchFolderPath - start path for creating list (all children folders are processed recursively)

// folderListArray - pass in array that will be append to with folders found from this function

// ignorePath - array of paths that should not be included in the final array

getFolderListRecursively = async (searchFolderPath, folderListArray, ignorePath)=>{

let list = await this.app.vault.adapter.list(searchFolderPath);

for( f of list.folders ) {

if( !f.toString(0).startsWith('.') && f.toString() != ignorePath ) {

folderListArray.push(f + '/');

await getFolderListRecursively( f, folderListArray, ignorePath );

}

}

};

// if archivePath is not assigned a path, present the user with a list of folders

if(archivePath==null) {

let folderList = [];

let currentPath = tp.file.folder(true);

if( currentPath != '') folderList.push('/');

await getFolderListRecursively( '/', folderList, currentPath )

let addRecentFolders = [];

for(let f of getRecentFoldersFromLocalStorage())

if(folderList.includes(f))

addRecentFolders.push(f);

folderList = folderList.filter( e=> !addRecentFolders.includes(e) );

folderList = addRecentFolders.concat(folderList);

archivePath = await tp.system.suggester( folderList, folderList ); //get destination folder from user

if(archivePath==null) return; //if user escapes out of suggester, stop script

}

if(tp.file.exists(archivePath + tp.file.title))

new Notice('A file with the same name exists in the target folder, so this file has not be moved', 10000)

else {

let currentFolderPath = tp.file.folder(true);

let currentFilePath = (currentFolderPath=='/' ? '' : currentFolderPath + '/') + tp.file.title + '.md';

let sortFileList = (await app.vault.adapter.list( currentFolderPath )).files.sort( (a, b)=> a.localeCompare(b) );

await tp.file.move( archivePath + tp.file.title ); // Archive current file

setRecentFolderToLocalStorage(archivePath)

let currentFileIndexInCurrentFolder = sortFileList.findIndex( e=>e==currentFilePath );

if ( sortFileList.length>1) { // open next file in folder, if one exists

let nextFileToOpen = '';

if( currentFileIndexInCurrentFolder == sortFileList.length-1 )

nextFileToOpen = sortFileList[0];

else

nextFileToOpen = sortFileList[currentFileIndexInCurrentFolder+1];

app.workspace.activeLeaf.openFile( tp.file.find_tfile(nextFileToOpen) );

}

}

%>
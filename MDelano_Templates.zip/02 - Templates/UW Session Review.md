#### Session Review
**Did you complete your session's targets?**

**What did I get done this session?**

**How did this compare to my normal work output?**

**Did I get bogged down? Where?**

**What went well? How can I replicate this in the future?**

**Any other takeaways? Lessons to share with others?**

**What are the next steps?**
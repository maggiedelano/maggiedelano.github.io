```button
name UW Session Begin
type append template
action UW Session Begin
remove true
color blue
```
```button
name UW Cycle - APPLY MANUALLY
type prepend template
action UW Cycle
```

```button
name UW Session Review
type append template
action UW Session Review
remove true
color blue
```
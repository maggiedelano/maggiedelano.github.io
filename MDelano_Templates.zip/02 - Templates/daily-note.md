---
tags: dailyNote
---

## Daily Journal

## Top Three Priorities
- [ ] 
- [ ] 
- [ ] 

## Morning Review
- [ ] assign next tag in OmniFocus (collect)
- [ ] add to Complice (plan)
- [ ] pick top three for today (prioritize)
- [ ] schedule on calendar (plan)

![[{{date:gggg-[W]ww}}#Top Three Priorities]]

![[{{date:YYYY-[Q]Q}}#{{date:gggg-[W]ww}}]]
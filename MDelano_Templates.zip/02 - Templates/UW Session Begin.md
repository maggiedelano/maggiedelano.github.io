### Ultrawork Session

#### Session Begin
40 min/ cycle (30 min work, 10 min break)
2 cycles = 1 hour, 20 min
3 cycles = 2 hours
6 cycles = 4 hours

**Number of cycles:**
**Start time:**
**Project:**

**What am I trying to accomplish?**

**Why is this important and valuable?**

**How will I know this is complete?**

**Potential distractions, procrastination?**
**How am I going to deal with them?**

**Is this concrete / measurable or subjective / ambiguous?**

**Anything else noteworthy?**
---
tags: weeklyNote
obsidianUIMode: preview
---

## Top Three Priorities
- [ ] 
- [ ] 
- [ ] 

## Semester Plan
![[{{date:YYYY-[Q]Q}}#{{date:gggg-[W]ww}}]]

## Weekly Review
- [ ] Zero inbox Personal
- [ ] Zero inbox Swarthmore (optional)
- [ ] Clean out drafts / Obsidian inbox
- [ ] Process all raindrop links
- [ ] Clean out computer desktop/downloads folder
- [ ] Review budget
- [ ] Check SEPTA balance
- [ ] Beeminder goal review
	- [ ] reflect on adding/changing/deleting goals
	- [ ] schedule vacations
- [ ] did I accomplish my top three priorities?
- [ ] Clean out iOS reminders / omnifocus inbox
- [ ] review projects in OmniFocus, generate next actions
- [ ] Plan week
	- [ ] Check semester plan and note important upcoming deadlines
	- [ ] choose three top priorities 
	- [ ] fill in priorities on next week's page
	- [ ] fill in semester plan on next week's page
	- [ ] Assign items to Mon-Fri/weekend
	- [ ] Screenshot old weekly plan and paste
	- [ ] Screenshot new weekly plan and paste


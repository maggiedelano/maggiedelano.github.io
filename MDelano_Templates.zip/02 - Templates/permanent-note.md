---
tags: [permanentNote,]
cssclass: permanentNote
---

# `=this.file.name`

## Literature Notes
## Reference Notes
## Fleeting Notes
## Relevant Notes
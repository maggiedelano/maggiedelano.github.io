---
title: {{title}}
author: [{{authorString}}]
aliases: {{title}}
year: {{year}}
doi: {{DOI}}
tags: [sources/article]
---

[Open in Zotero: {{title}}]({{zoteroSelectURI}})

# {{title}}

## Abstract
{{abstract}}

## Summary of key points
- 

## Fleeting notes
- 

## Highlights
{{note}}
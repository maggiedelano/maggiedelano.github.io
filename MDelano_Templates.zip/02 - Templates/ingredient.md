---
ingredient: 
category: 
tags: [ingredient, ]
---

# `=this.ingredient`

### Used in these recipes 

```dataviewjs
dv.list(dv.pages()
	.where(p => p.recipe && p.ingredients.indexOf(dv.current().ingredient) >= 0).file.link);
```
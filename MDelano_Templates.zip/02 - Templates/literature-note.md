---
tags: [literatureNote]
cssclass: literatureNote
---

# `=this.file.name`

## One Paragraph Summary
## People
## Terms
## Questions
## Propositions
## Reference Notes
## Fleeting Notes
## Relevant Notes

#### Ultrawork Cycle at {{time}}
```button
name pomo
type command
action Status Bar Pomodoro Timer: Start pomodoro
color default
```
^button-m014
##### Begin
**What am I trying to accomplish this cycle?**

**How will I get started?**

**Any hazards? How will I counter them?**

**energy:**
**morale:**

##### Notes 

##### Review

**Completed Cycle's target?:**

**Anything noteworthy?**

**Any distractions?**

**Things to improve for next cycle?**
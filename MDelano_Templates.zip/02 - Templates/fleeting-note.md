---
tags: fleetingNote
---

[[{{date:YYYY-MM-DD}}]]

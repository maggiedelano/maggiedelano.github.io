##### Review

**Completed Cycle's target?:**

**Anything noteworthy?**

**Any distractions?**

**Things to improve for next cycle?**
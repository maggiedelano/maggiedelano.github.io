- # RBC6 Goals 
    - To facilitate RBC members connecting to their deeper "whys" in life - what are the greater questions they are interested in answering? How can Roam and RBC help that?
    - To facilitate RBC members in following their curiosity and exploring texts and ideas more deeply
    - To provide instruction and practice in engaging in inspectional, analytical and syntopical reading
    - To provide reference material for the "essential texts" covered in RBC thus far and some possibilities for implementations using Roam, especially [[How To Take Smart Notes]] and [[How To Read A Book]]
    - To help RBC members "take home" what they have learned in RBC to their own graphs and lives
    - To create a welcoming environment for RBC members to learn and improve on their skills using Roam, including indentation practices and block references
    - To create a welcoming environment for RBC members to get to meet and learn from each other
- # RBC6 Guiding Principles
    - ## Operate at the edge of chaos
        - RBC was introduced to the idea of the "edge of chaos" during our first book club where we read __Where Good Ideas Come From__ by Steven Johnson. It's our goal in RBC to find the right balance between order and chaos, providing scaffolding to encourage curiosity and innovation:
            - > The computer scientist Christopher Langton observed several decades ago that innovative systems have a tendency to gravitate toward the “edge of chaos”: the fertile zone between too much order and too much anarchy. (The notion is central to Stuart Kauffman’s idea of the adjacent possible, as well.) Langton sometimes uses the metaphor of different phases of matter—gas, liquid, solid—to describe these network states. Think of the behavior of molecules in each of these three conditions. In a gas, chaos rules; new configurations are possible, but they are constantly being disrupted and torn apart by the volatile nature of the environment. In a solid, the opposite happens: the patterns have stability, but they are incapable of change. But a liquid network creates a more promising environment for the system to explore the adjacent possible. New configurations can emerge through random connections formed between molecules, but the system isn’t so wildly unstable that it instantly destroys its new creations. 

Johnson, Steven. Where Good Ideas Come From (p. 52).
        - From this, we've learned of the importance of [[🧰 Graph Conventions]] that are clear but not too restrictive.
    - ## Writing is thinking
        - It is not uncommon to think of writing as something that happens __after__ we've done our research. However, as we learned in RBC2 (and RBC3 and RBC4!), writing __is__ thinking, and writing well can help facilitate new insights:
            - > If you understand what you read and translate it into the different context of your own thinking, materialised in the slip-box, you cannot help but transform the findings and thoughts of others into something that is new and your own.

Ahrens, Sönke. How to Take Smart Notes: One Simple Technique to Boost Writing, Learning and Thinking – for Students, Academics and Nonfiction Book Writers (p. 74). 
            - > “One cannot think without writing.” (Luhmann 1992, 53)
        - From this, we've learned of the importance of writing prompts, be they weekly reading assignments or daily ones.
    - ## Vulnerability creates opportunities for deeper connection
        - In RBC3, we learned all about what it takes to create connections between people that foster collaboration. One thing that helps create connection is being vulnerable; by bringing our most authentic selves to RBC, we can create deeper and more meaningful connections:
            - > “People tend to think of vulnerability in a touchy-feely way, but that’s not what’s happening,” Polzer says. “It’s about sending a really clear signal that you have weaknesses, that you could use help. And if that behavior becomes a model for others, then you can set the insecurities aside and get to work, start to trust each other and help each other. If you never have that vulnerable moment, on the other hand, then people will try to cover up their weaknesses, and every little microtask becomes a place where insecurities manifest themselves.” 

Coyle, Daniel. The Culture Code (p. 104). 
        - From this, we've learned the value of curating spaces where people can be vulnerable and share, whether in breakout rooms or the shared graph.
    - ## All flourishing is mutual
        - RBC4 introduced us to the poetic writing of Robin Wall Kimmerer in __Braiding Sweetgrass__. Throughout the book, Robin describes how plants operate in sync with one another, and how us humans can reconnect to the Earth through respectful harvesting practices:
            - > If one tree fruits, they all fruit—there are no soloists. Not one tree in a grove, but the whole grove; not one grove in the forest, but every grove; all across the county and all across the state. The trees act not as individuals, but somehow as a collective. Exactly how they do this, we don’t yet know. But what we see is the power of unity. What happens to one happens to us all. We can starve together or feast together. All flourishing is mutual. 

Kimmerer, Robin Wall. Braiding Sweetgrass (p. 15).  
        - From this, we've learned that we should support each and every member and that one member achieving their goals helps us all.
    - ## Evaluate the arguments
        - In RBC5, we read __How To Read A Book__ and learned all about the importance of analyzing and evaluating arguments in text. We also learned that it is important to focus on the author's arguments and reasons rather than our emotional responses to the book (when our goal is to increase understanding). When disagreeing with an author, we should clearly state where the author is uninformed, misinformed, illogical, or incomplete. While our evidentiary standards might vary book to book, person to person, or project to project, we appreciate the role that evaluating arguments can place in increasing our understanding:
            - > The author may be honest in declaring himself on matters of fact or knowledge. We usually proceed in that trust. But unless we are exclusively interested in the author’s personality, we should not be satisfied with knowing what his opinions are. His propositions are nothing but expressions of personal opinion unless they are supported by reasons. If it is the book and the subject with which it deals that we are interested in, and not just the author, we want to know not merely what his propositions are, but also why he thinks we should be persuaded to accept them.

Van Doren, Charles; Mortimer J. Adler. How to Read a Book (p. 114).
        - From this, we've learned of the importance of [[analytical reading]] and using an [[argument map]].
    - ## Follow the whys
        - In RBC6, we plan to focus on the most advanced form of reading presented in __How To Read Book__: syntopical reading. Here's Adler and Van Doren:
            - > When reading syntopically, the reader reads many books, not just one, and places them in relation to one another and to a subject about which they all revolve. But mere comparison of texts is not enough. Syntopical reading involves more. With the help of the books read, the syntopical reader is able to construct an analysis of the subject that may not be in any of the books. It is obvious, therefore, that syntopical reading is the most active and effortful kind of reading.

Van Doren, Charles; Mortimer J. Adler. How to Read a Book (p. 20)
        - Ultimately, syntopical reading is about helping us answer __our own questions__, rather than those of the authors we are reading. We'll help you identify your "whys" and how RBC6 and our chosen books can help you get there.

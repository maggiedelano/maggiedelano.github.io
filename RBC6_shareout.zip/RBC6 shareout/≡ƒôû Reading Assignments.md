- # Overview
    - For this RBC, we'll be conducting a [[syntopical reading]] of two books: [[Cal Newport]]'s [[So Good They Can't Ignore You]] and [[David Epstein]]'s [[Range]]. We will be using a method inspired by the book we read in the last RBC called [[How To Read A Book]]. 
    - A syntopical reading involves using texts to answer our own questions; as such, we aren't going to be reading these books in a typical way. Instead, we'll systematically skim each book and then revisit the passages that are most relevant to us, using passages from both books to answer our ultimate questions. 
    - There will be a reading assignment each week. Below is an overview of what you'll be doing for each reading; click on the live session page for more information about how to prepare for each week.
- # Overview
    - [[syntopical reading]] consists of several stages:
        1. select a bibliography (done already in our case)
        2. read all the texts inspectionally (weeks 1 and 2)
        3. select passages (week 3)
        4. come to terms (week 3)
        5. get the questions clear (week 3)
        6. defining the issues (weeks 4 and 5)
        7. analyzing the discussion (weeks 4 and 5)
        8. generating our own ideas (weeks 4 and 5)
        9. producing output (week 6)
- # Weekly Reading Assignments
    - [[Week 1 Reading Assignment]] - [[inspectional reading]] of [[Range]]
    - [[Week 2 Reading Assignment]] - [[inspectional reading]] of [[So Good They Can't Ignore You]]
    - [[Week 3 Reading Assignment]] - selecting passages, coming to terms, getting the questions clear
    - [[Week 4 Reading Assignment]] - defining the issues, analyzing the discussion, generating our own ideas
    - [[Week 5 Reading Assignment]] - defining the issues, analyzing the discussion, generating our own ideas
    - [[Week 6 Reading Assignment]] - wrap up analysis, discuss outputs, feedback and next RBC
